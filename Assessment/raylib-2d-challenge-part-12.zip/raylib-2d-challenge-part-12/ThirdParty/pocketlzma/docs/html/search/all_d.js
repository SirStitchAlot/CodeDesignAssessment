var searchData=
[
  ['undefinederror_79',['UndefinedError',['../namespaceplz.html#ab475d5ed0e7986cf350584401ffa72c1a98570a3d51c80b5961c408f204e48cd1',1,'plz']]],
  ['usepreset_80',['usePreset',['../classplz_1_1PocketLzma.html#a79afe307becacc0032440b0bc77fa8ee',1,'plz::PocketLzma::usePreset()'],['../classplz_1_1Settings.html#a48c767a7ab1529019eb5c93924bcff59',1,'plz::Settings::usePreset()']]]
];
