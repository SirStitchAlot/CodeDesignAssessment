var indexSectionsWithContent =
{
  0: "bcdefgilmopstuv",
  1: "fmps",
  2: "p",
  3: "fmps",
  4: "cdefmpstuv",
  5: "dflp",
  6: "cps",
  7: "bdefgiou",
  8: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

