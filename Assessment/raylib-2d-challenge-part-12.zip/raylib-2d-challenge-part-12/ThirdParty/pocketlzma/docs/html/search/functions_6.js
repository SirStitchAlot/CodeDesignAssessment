var searchData=
[
  ['set_113',['set',['../classplz_1_1FileStatus.html#a9501f0a4561a9c822cbf216245748326',1,'plz::FileStatus']]],
  ['setsettings_114',['setSettings',['../classplz_1_1PocketLzma.html#a7d24b5036874adfe77730ec5868d8fe9',1,'plz::PocketLzma']]],
  ['settings_115',['Settings',['../classplz_1_1Settings.html#ad728bfb6af28aea1250adaf458b0970a',1,'plz::Settings::Settings()=default'],['../classplz_1_1Settings.html#ab96e99e4ad98ce06fab0cfb063c0ad08',1,'plz::Settings::Settings(Preset preset)']]],
  ['size_116',['size',['../classplz_1_1MemoryStream.html#acaab201e02634a1167d57070dca2fd1e',1,'plz::MemoryStream']]],
  ['status_117',['status',['../classplz_1_1FileStatus.html#abc7783bc02e8f067bc58c03c79738358',1,'plz::FileStatus']]]
];
