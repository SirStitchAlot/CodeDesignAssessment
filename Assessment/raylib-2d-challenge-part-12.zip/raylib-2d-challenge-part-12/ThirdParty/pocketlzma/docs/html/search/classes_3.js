var searchData=
[
  ['settings_87',['Settings',['../classplz_1_1Settings.html',1,'plz']]]
];
