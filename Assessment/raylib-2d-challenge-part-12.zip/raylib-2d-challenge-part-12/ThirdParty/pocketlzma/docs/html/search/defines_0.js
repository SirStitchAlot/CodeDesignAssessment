var searchData=
[
  ['pocketlzma_5fversion_5fmajor_168',['POCKETLZMA_VERSION_MAJOR',['../PocketLzmaConfig_8h.html#a6d8a3b4eb6fbccfa9c263e9c126748a3',1,'PocketLzmaConfig.h']]],
  ['pocketlzma_5fversion_5fminor_169',['POCKETLZMA_VERSION_MINOR',['../PocketLzmaConfig_8h.html#afeb77d781a57b6d8b42348d946a6c115',1,'PocketLzmaConfig.h']]],
  ['pocketlzma_5fversion_5fpatch_170',['POCKETLZMA_VERSION_PATCH',['../PocketLzmaConfig_8h.html#a196317898f98d0eb6fd9c5c90ea415e3',1,'PocketLzmaConfig.h']]]
];
