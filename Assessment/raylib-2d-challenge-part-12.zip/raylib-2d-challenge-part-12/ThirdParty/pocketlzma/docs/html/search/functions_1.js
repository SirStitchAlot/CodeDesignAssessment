var searchData=
[
  ['decompress_102',['decompress',['../classplz_1_1PocketLzma.html#aa4ab7bd87b9ccd2924fb37b03dec776d',1,'plz::PocketLzma::decompress(const std::vector&lt; uint8_t &gt; &amp;input, std::vector&lt; uint8_t &gt; &amp;output)'],['../classplz_1_1PocketLzma.html#a0a5704b36a3afa512336071ff43c8eb3',1,'plz::PocketLzma::decompress(const uint8_t *input, const size_t inputSize, std::vector&lt; uint8_t &gt; &amp;output)']]],
  ['decompressbuffered_103',['decompressBuffered',['../classplz_1_1PocketLzma.html#ae818b49d5569bde7eccb0216c6cdbff6',1,'plz::PocketLzma::decompressBuffered(const std::vector&lt; uint8_t &gt; &amp;input, std::vector&lt; uint8_t &gt; &amp;output, uint32_t bufferSize=PLZ_BUFFER_SIZE)'],['../classplz_1_1PocketLzma.html#a43a5b339599b2a2e16ce8375b448dfea',1,'plz::PocketLzma::decompressBuffered(const uint8_t *input, const size_t inputSize, std::vector&lt; uint8_t &gt; &amp;output, uint32_t bufferSize=PLZ_BUFFER_SIZE)']]]
];
