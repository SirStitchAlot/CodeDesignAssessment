var searchData=
[
  ['preset_138',['Preset',['../namespaceplz.html#a0a5202cef968a7019be130a177a90790',1,'plz']]]
];
