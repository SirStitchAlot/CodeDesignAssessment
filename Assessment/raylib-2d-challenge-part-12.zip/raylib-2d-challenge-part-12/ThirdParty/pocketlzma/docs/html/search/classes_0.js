var searchData=
[
  ['file_82',['File',['../classplz_1_1File.html',1,'plz']]],
  ['filestatus_83',['FileStatus',['../classplz_1_1FileStatus.html',1,'plz']]]
];
