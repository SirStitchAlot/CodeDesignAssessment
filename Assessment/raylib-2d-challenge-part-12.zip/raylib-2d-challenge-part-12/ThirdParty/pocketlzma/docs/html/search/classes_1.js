var searchData=
[
  ['memorybuffer_84',['MemoryBuffer',['../classplz_1_1MemoryBuffer.html',1,'plz']]],
  ['memorystream_85',['MemoryStream',['../classplz_1_1MemoryStream.html',1,'plz']]]
];
