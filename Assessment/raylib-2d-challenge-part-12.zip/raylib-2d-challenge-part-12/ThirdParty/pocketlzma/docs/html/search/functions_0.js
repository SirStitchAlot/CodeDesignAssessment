var searchData=
[
  ['category_99',['category',['../classplz_1_1FileStatus.html#abe45382880648959bbcda81484c62ca2',1,'plz::FileStatus']]],
  ['code_100',['code',['../classplz_1_1FileStatus.html#a28bd31db1508cbd77bf1701537a94e2b',1,'plz::FileStatus']]],
  ['compress_101',['compress',['../classplz_1_1PocketLzma.html#ad1d5ed42c001ca43633924836f64a2cc',1,'plz::PocketLzma::compress(const std::vector&lt; uint8_t &gt; &amp;input, std::vector&lt; uint8_t &gt; &amp;output)'],['../classplz_1_1PocketLzma.html#a3633dfb40f8838c2de605f76b37d6c48',1,'plz::PocketLzma::compress(const uint8_t *input, const size_t inputSize, std::vector&lt; uint8_t &gt; &amp;output)']]]
];
