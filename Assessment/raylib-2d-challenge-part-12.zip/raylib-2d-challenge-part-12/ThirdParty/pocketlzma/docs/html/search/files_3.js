var searchData=
[
  ['settings_2ehpp_98',['Settings.hpp',['../Settings_8hpp.html',1,'']]]
];
