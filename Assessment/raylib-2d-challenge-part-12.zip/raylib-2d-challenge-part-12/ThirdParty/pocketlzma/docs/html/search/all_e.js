var searchData=
[
  ['validate_81',['validate',['../classplz_1_1Settings.html#aee9ea3e8866a819a8877534f195301c6',1,'plz::Settings']]]
];
