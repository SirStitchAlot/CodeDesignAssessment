var searchData=
[
  ['category_1',['category',['../classplz_1_1FileStatus.html#abe45382880648959bbcda81484c62ca2',1,'plz::FileStatus']]],
  ['code_2',['Code',['../classplz_1_1FileStatus.html#a38527d84244313f3874c444623eccb92',1,'plz::FileStatus::Code()'],['../classplz_1_1FileStatus.html#a28bd31db1508cbd77bf1701537a94e2b',1,'plz::FileStatus::code() const']]],
  ['compress_3',['compress',['../classplz_1_1PocketLzma.html#ad1d5ed42c001ca43633924836f64a2cc',1,'plz::PocketLzma::compress(const std::vector&lt; uint8_t &gt; &amp;input, std::vector&lt; uint8_t &gt; &amp;output)'],['../classplz_1_1PocketLzma.html#a3633dfb40f8838c2de605f76b37d6c48',1,'plz::PocketLzma::compress(const uint8_t *input, const size_t inputSize, std::vector&lt; uint8_t &gt; &amp;output)']]]
];
