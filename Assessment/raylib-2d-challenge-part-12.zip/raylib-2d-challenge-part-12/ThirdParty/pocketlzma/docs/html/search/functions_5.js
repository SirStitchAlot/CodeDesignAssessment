var searchData=
[
  ['pocketlzma_112',['PocketLzma',['../classplz_1_1PocketLzma.html#a40aa192616f680ede6f318b65d4dd05a',1,'plz::PocketLzma::PocketLzma()=default'],['../classplz_1_1PocketLzma.html#abf709fc680f8f3019dce62e0c8c67ab8',1,'plz::PocketLzma::PocketLzma(Preset preset)'],['../classplz_1_1PocketLzma.html#a6aec8bb1d4226a88689857f057f11596',1,'plz::PocketLzma::PocketLzma(const Settings &amp;settings)']]]
];
