var searchData=
[
  ['decompress_4',['decompress',['../classplz_1_1PocketLzma.html#aa4ab7bd87b9ccd2924fb37b03dec776d',1,'plz::PocketLzma::decompress(const std::vector&lt; uint8_t &gt; &amp;input, std::vector&lt; uint8_t &gt; &amp;output)'],['../classplz_1_1PocketLzma.html#a0a5704b36a3afa512336071ff43c8eb3',1,'plz::PocketLzma::decompress(const uint8_t *input, const size_t inputSize, std::vector&lt; uint8_t &gt; &amp;output)']]],
  ['decompressbuffered_5',['decompressBuffered',['../classplz_1_1PocketLzma.html#ae818b49d5569bde7eccb0216c6cdbff6',1,'plz::PocketLzma::decompressBuffered(const std::vector&lt; uint8_t &gt; &amp;input, std::vector&lt; uint8_t &gt; &amp;output, uint32_t bufferSize=PLZ_BUFFER_SIZE)'],['../classplz_1_1PocketLzma.html#a43a5b339599b2a2e16ce8375b448dfea',1,'plz::PocketLzma::decompressBuffered(const uint8_t *input, const size_t inputSize, std::vector&lt; uint8_t &gt; &amp;output, uint32_t bufferSize=PLZ_BUFFER_SIZE)']]],
  ['default_6',['Default',['../namespaceplz.html#a0a5202cef968a7019be130a177a90790a7a1920d61156abc05a60135aefe8bc67',1,'plz']]],
  ['dictionarysize_7',['dictionarySize',['../classplz_1_1Settings.html#ab36901bc8cc07bb4326d880c1a0d8ceb',1,'plz::Settings']]]
];
