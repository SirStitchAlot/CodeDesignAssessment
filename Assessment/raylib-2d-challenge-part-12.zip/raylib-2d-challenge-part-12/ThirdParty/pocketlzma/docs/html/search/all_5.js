var searchData=
[
  ['goodcompression_38',['GoodCompression',['../namespaceplz.html#a0a5202cef968a7019be130a177a90790ad16c021f6844bf9ed334adbe75bd2360',1,'plz']]]
];
