var searchData=
[
  ['bestcompression_0',['BestCompression',['../namespaceplz.html#a0a5202cef968a7019be130a177a90790af64dad5d67efafede84c0ad786be85b2',1,'plz']]]
];
