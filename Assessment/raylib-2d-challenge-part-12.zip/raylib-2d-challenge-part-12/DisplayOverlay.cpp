/** DisplayOverlay.cpp
 * 
 * See header file for details.
 */

#include "DisplayOverlay.h"

DisplayOverlay::DisplayOverlay() {

}

DisplayOverlay::~DisplayOverlay() {
    
}

void DisplayOverlay::draw(const Scene &scene) {

}