/** CommandListener.cpp
 *
 * See header file for details.
 */

#include "Commandlistener.h"

CommandListener::CommandListener() {
}

CommandListener::~CommandListener() {
}
	
void CommandListener::goUp() {
}
	
void CommandListener::goLeft() {
}
	
void CommandListener::goRight() {
}
	
void CommandListener::goDown() {
}

void CommandListener::goNowhere() {
}
	
void CommandListener::doInteractWith() {
}

void CommandListener::doExit() {
}

void CommandListener::handleKeyPress(int key) {
}